
#16119032
#Jordan Gray
#Assignment 3 Part 2

import os #os module imported here

import cImage

def selectImageFiles():
    dirs = os.listdir("images/")

    count=0

    print("\nThese image files are visible:")
    for file in dirs:
        if(".gif" in file):
            print (str(count) + ' : ' + file)
            count=count+1
    option = int(input("Select the file by number: "))

    print("\nSelected: images/"+dirs[option])
    return dirs[option]
#listdir()

while(True):
    print("*** Image Framing Program ***\n\
q - quit\n\
f - select an image file\n\
c - add a new colour\n\
p - pick a colour\n\
d - display a framed image for the file\n")

    options = input("Enter a command: ")
    loadedimagefile = False

    if(options == "q") or (options == "Q"):
            quit()

    elif(options == "f") or (options == "F"):
        gifFile=selectImageFiles()
        ac = cImage.FileImage(gifFile)
        loadedimagefile = True #This is to Set that the text file is valid before proceeding with functions


    if(loadedimagefile): #This is to check that the text file is valid before proceeding with functions
        if(options=="c") or (options == "C"):
            print("x")
        elif(options=="p") or (options == "P"):
            print()

        elif(options=="d") or (options == "D"):

    else:
        print("You have not yet loaded in a file!")


