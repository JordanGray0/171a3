#16119032
#Jordan Gray
#Assignment 3 Part 1
import os #os module imported here
import random

dictionaryWordList = {}

def read_file(filename):
    try:
        file = open(filename, "r") # open the file
        word_List = file.readlines() # load each line into a list
        file.close() # close the file
        word_List = [words.strip() for words in word_List]
    except FileNotFoundError:
         print('File does not exist')
         return
    return word_List

def loadTextAllFiles():
    dictionaryWordList["Adjectiveslist"] = read_file("Adjectives.txt")
    dictionaryWordList["Adverbslist"] = read_file("Adverbs.txt")
    dictionaryWordList["Conjunctionslist"] = read_file("Conjunctions.txt")
    dictionaryWordList["IntransitiveVerbslist"] = read_file("IntransitiveVerbs.txt")
    dictionaryWordList["Leadinlist"] = read_file("Leadin.txt")
    dictionaryWordList["NounMarkerslist"] = read_file("NounMarkers.txt")
    dictionaryWordList["Nounslist"] = read_file("Nouns.txt")
    dictionaryWordList["TransitiveVerbslist"] = read_file("TransitiveVerbs.txt")
    print("All Files are loaded")
    return dictionaryWordList

def DisplayFirstWordFromEachList():
    for d in dictionaryWordList:
        x = dictionaryWordList[d][0]
        print(x)

def randomTwoWordSentene():
    line = random.choice(dictionaryWordList["Nounslist"])
    line += " "
    line += random.choice(dictionaryWordList["IntransitiveVerbslist"])
    line += "."
    print(line)

def newConformingSentence():

    Noun_Phrase = dictionaryWordList["Nounslist"][0]
    <Sentence>::= [<Lead-in>] <Noun_Phrase> [<Adverb>] <Verb-Phrase>
    <Noun-Phrase> ::= <Noun-marker> [ <Adjective> ] <Noun>
    <Verb-Phrase> ::= <Intransitive-verb> | <Transitive-verb> <Noun-phrase>
while(True):
    print("*** Random Sentence generator ***\n\
    L: load all the files of words from disk.\n\
    T: test—display the first word from each list to make sure they’ve\n\
    been loaded.\n\
    E: easy sentence: display a two word sentence - a randomly selectedn\
    noun followed by a randomly selected intransitive verb and then a\n\
    full stop.\n\
    S: new Sentence—generate and display a sentence conforming to the\n\
    grammar defined in the Grammatical Definition of the Sentences section\n\
    on the next page. If the wordlists haven’t been loaded, display\n\
    an error message.\n\
    Q: quit the program\n")

    options = input("command: ")
    loadedtextfile = False

    if(options == "q") or (options == "Q"):
            quit()

    elif(options == "l") or (options == "L"):
        loadTextAllFiles()
        loadedtextfile = True #This is to Set that the text file is valid before proceeding with functions
        print(dictionaryWordList)
    if(loadedtextfile): #This is to check that the text file is valid before proceeding with functions
        if(options=="t") or (options == "T"):
            DisplayFirstWordFromEachList()
        elif(options=="e") or (options == "E"):
            randomTwoWordSentene()
        elif(options=="s") or (options == "S"):
            newConformingSentence()
    else:
        print("You have not yet loaded in a file!")
